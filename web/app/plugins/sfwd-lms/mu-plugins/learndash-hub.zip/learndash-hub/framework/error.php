<?php

namespace LearnDash\Hub\Framework;

/**
 * Class Error
 *
 * @package Projects
 */
class Error {
	const INVALID = 1;
}
